#pragma once

namespace TypeIds
{
	constexpr int SCV = 0;
	constexpr int Mineral = 1;
}
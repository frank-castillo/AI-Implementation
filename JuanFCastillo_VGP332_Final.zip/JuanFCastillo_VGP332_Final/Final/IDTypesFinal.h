#pragma once

enum EntityTypes
{
	SurvivorType,
	ZombieType,
	AmmoType
};
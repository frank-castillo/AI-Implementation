#pragma once

enum Types
{
	SCVID
};
#pragma once

enum class PathMethod
{
	None,
	BFS,
	DFS,
	Dijkastra,
	ASTAR
};

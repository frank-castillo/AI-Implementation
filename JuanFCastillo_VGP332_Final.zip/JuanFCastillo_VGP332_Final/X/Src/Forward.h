//====================================================================================================
// Filename:	Forward.h
// Created by:	Peter Chan
//====================================================================================================

#ifndef INCLUDED_XENGINE_FORWARD_H
#define INCLUDED_XENGINE_FORWARD_H

namespace X {

class Texture;

} // namespace X

#endif // #ifndef INCLUDED_XENGINE_FORWARD_H
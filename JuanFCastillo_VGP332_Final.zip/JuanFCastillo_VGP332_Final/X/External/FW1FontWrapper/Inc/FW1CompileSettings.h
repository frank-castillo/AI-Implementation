// FW1CompileSettings.h

#ifndef IncludeGuard__FW1_FW1CompileSettings_h
#define IncludeGuard__FW1_FW1CompileSettings_h


// Define if building a DLL for the font-wrapper
#define FW1_COMPILETODLL

// Define to use LoadLibrary instead of linking to DLLs
#define FW1_DELAYLOAD_DWRITE_DLL
#define FW1_DELAYLOAD_D3DCOMPILER_XX_DLL


#endif// IncludeGuard__FW1_FW1CompileSettings_h

#pragma once

enum Types
{
	SurvivorID,
	ZombieID
};
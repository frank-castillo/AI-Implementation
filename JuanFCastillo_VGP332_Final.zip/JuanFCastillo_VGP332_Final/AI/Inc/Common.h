#pragma once

#include <XEngine.h>
// When you use an Include, the preprocessor goes directly to the file
// "" for something on your local solution
// The include literally copy-pastes all the lines of code included in the file we are opening
// It is red because we have to set up a path and AI depends on X for accessing math
// All we do is add the property sheet and references